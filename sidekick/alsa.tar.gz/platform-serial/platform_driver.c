/*
 * Linux platform driver example
 *
 */
#include <linux/device.h>
#include <linux/init.h>
#include <linux/kernel.h>
#include <linux/module.h>
#include <linux/platform_device.h>

#include "platform_driver.h"

static int platform_example_probe(struct platform_device *pdev)
{
	struct resource *r;
	struct platform_example_data *pdata = pdev->dev.platform_data;

	/* Add per-device initialization code here */

	dev_notice(&pdev->dev, "probe() called, value: %d\n",
			pdata ? pdata->value : -1);
	printk(KERN_INFO "Num Resources: %d\n", pdev->num_resources);
        r = platform_get_resource(pdev, IORESOURCE_IO, 0);
	printk(KERN_INFO "Resource Start: %04x\n", r->start);
	printk(KERN_INFO "Resource End: %04x\n", r->end);

	return 0;
}

static int platform_example_remove(struct platform_device *pdev)
{
	/* Add per-device cleanup code here */

	dev_notice(&pdev->dev, "remove() called\n");

	return 0;
}

#ifdef CONFIG_PM
static int
platform_example_suspend(struct platform_device *pdev, pm_message_t state)
{
	/* Add code to suspend the device here */

	dev_notice(&pdev->dev, "suspend() called\n");

	return 0;
}

static int platform_example_resume(struct platform_device *pdev)
{
	/* Add code to resume the device here */

	dev_notice(&pdev->dev, "resume() called\n");

	return 0;
}
#else
/* No need to do suspend/resume if power management is disabled */
# define platform_example_suspend	NULL
# define platform_example_resume	NULL
#endif

static struct platform_driver platform_example_driver = {
	.probe		= platform_example_probe,
	.remove		= platform_example_remove,
	.suspend	= platform_example_suspend,
	.resume		= platform_example_resume,
	.driver	= {
		.name	= "platform_example",
	},
};

static int __init platform_example_init(void)
{
	return platform_driver_register(&platform_example_driver);
}
module_init(platform_example_init);

static void __exit platform_example_exit(void)
{
	platform_driver_unregister(&platform_example_driver);
}
module_exit(platform_example_exit);

/* Information about this module */
MODULE_DESCRIPTION("Platform driver example");
MODULE_AUTHOR("Atmel Corporation");
MODULE_LICENSE("Dual BSD/GPL");
