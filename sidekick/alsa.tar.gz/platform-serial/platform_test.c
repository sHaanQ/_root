/*
 * Linux platform device test module
 *
*/

#include <linux/init.h>
#include <linux/kernel.h>
#include <linux/module.h>
#include <linux/platform_device.h>
#include <linux/slab.h>

#include "platform_driver.h"

#define PLATFORM_DEVICE_NAME	"platform_example"

static int value;
module_param(value, int, S_IRUGO);
MODULE_PARM_DESC(value, "Value to pass as platform data");

static struct resource serial_resources[] = {
	{
		.start	= 0x03f8,
		.end	= 0x03ff,
		.flags	= IORESOURCE_IO,
		.name	= "io-port"
	}
};

/* Keep track of the devices so that we can free them later */
static struct platform_device device = {
	.name = PLATFORM_DEVICE_NAME,
	.id = 0,
	.resource = serial_resources,
        .num_resources=1
};

static void platform_test_release(struct device *dev)
{
	printk("** release() **\n");
}


static int __init platform_test_init(void)
{
	struct platform_device *pdev;
	struct platform_example_data data;
	int ret;

	/*
	 * Initialize platform data. In this case, we pass the same
	 * value with all the devices -- real platform devices usually
	 * have platform-specific data which may be different from
	 * device to device.
	 */
	data.value = value;

	/*
	 * The data is copied into a new dynamically allocated
	 * structure, so it's ok to pass variables defined on
	 * the stack here.
	 */
	/*
	ret = platform_device_add_data(pdev, &data, sizeof(data));
	if (ret)
		goto fail;
	*/
	pdev = &device;
	printk(KERN_INFO "Registering device \"%s.%d\"...\n",
			pdev->name, pdev->id);
	pdev->dev.release = platform_test_release;

	ret = platform_device_register(&device);
	if (ret)
		goto fail;
/*
	pdev = platform_device_register_simple(PLATFORM_DEVICE_NAME, -1, NULL, 0);
	if (IS_ERR(pdev))
	{
		ret = PTR_ERR(pdev);
		goto fail;
	}
*/
	return 0;

fail:
	/*
	 * The last device was never registered, so we may free it
	 * directly. The others, however, were, so we must unregister
	 * them. They are freed automatically when the last reference
	 * goes away.
	 *
	 * In both cases, any dynamically allocated resources and
	 * platform data will be freed automatically.
	 */

	return ret;
}
module_init(platform_test_init);

static void __exit platform_test_exit(void)
{
	struct platform_device *pdev;

	pdev = &device;

	if (pdev)
		printk(KERN_INFO "Removing device %s...\n",
				pdev->name);

	/* If pdev is NULL, this is a no-op */
	platform_device_unregister(&device);

}
module_exit(platform_test_exit);

/* Information about this module */
MODULE_DESCRIPTION("Platform device test module");
MODULE_AUTHOR("Atmel Corporation");
MODULE_LICENSE("Dual BSD/GPL");
