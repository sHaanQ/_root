alsa driver example
  dummy.c
    dummy sound card - this card does not do any output or input, but you
    may use this module for any application which requires a sound card
    (like RealPlayer).
  insmod dummy.ko
  Test with 6735l1, l2, l3, l4

